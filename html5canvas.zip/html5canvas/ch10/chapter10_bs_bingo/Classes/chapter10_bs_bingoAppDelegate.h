//
//  chapter10_bs_bingoAppDelegate.h
//  chapter10_bs_bingo
//
//  Created by Jeff Fulton on 12/1/10.
//  Copyright 8bitrocket 2010. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "PhoneGapDelegate.h"

@interface chapter10_bs_bingoAppDelegate : PhoneGapDelegate {
}

@end

